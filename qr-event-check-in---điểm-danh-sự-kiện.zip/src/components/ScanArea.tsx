import React, { useState, useEffect, useRef } from 'react';
import { Camera, X, CheckCircle2, AlertCircle, Send, SwitchCamera, Upload, Info, RefreshCw, Users, User } from 'lucide-react';
import { Html5Qrcode } from 'html5-qrcode';
import { ScanFeedback } from '../types/attendance';
import { findStudentByMssv, ADVISOR_CLASSES, AdvisorClass } from '../utils/storage';

interface ScanAreaProps {
  onCheckIn: (
    rawCode: string,
    method: 'qr' | 'manual',
    manualDetails?: { name?: string; className?: string }
  ) => void;
  feedback: ScanFeedback;
  onClearFeedback: () => void;
}

export const ScanArea: React.FC<ScanAreaProps> = ({
  onCheckIn,
  feedback,
  onClearFeedback,
}) => {
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [manualCode, setManualCode] = useState('');
  const [manualName, setManualName] = useState('');
  const [selectedClass, setSelectedClass] = useState<AdvisorClass>('LỚP 1');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isScanningActive, setIsScanningActive] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [hasMultipleCameras, setHasMultipleCameras] = useState(false);

  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);
  const isHandlingScanRef = useRef<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [retryKey, setRetryKey] = useState(0);

  // Initialize and run scanner when modal is opened or retry triggered
  useEffect(() => {
    let isMounted = true;

    if (!isScannerOpen) {
      if (html5QrCodeRef.current) {
        if (isScanningActive) {
          html5QrCodeRef.current
            .stop()
            .then(() => {
              html5QrCodeRef.current?.clear();
              setIsScanningActive(false);
            })
            .catch(() => setIsScanningActive(false));
        }
      }
      return;
    }

    setCameraError(null);
    const scannerElementId = 'qr-reader-viewport';

    // Delay slight tick to allow DOM element to render
    const timer = setTimeout(async () => {
      if (!isMounted) return;

      try {
        // Clean up previous scanner if any exists
        if (html5QrCodeRef.current) {
          try {
            if (html5QrCodeRef.current.isScanning) {
              await html5QrCodeRef.current.stop();
            }
            html5QrCodeRef.current.clear();
          } catch {
            // Ignore cleanup error
          }
          html5QrCodeRef.current = null;
        }

        const scanner = new Html5Qrcode(scannerElementId);
        html5QrCodeRef.current = scanner;

        // Try environment camera first, then fall back to user camera
        const qrConfig = {
          fps: 15,
          qrbox: (viewfinderWidth: number, viewfinderHeight: number) => {
            const minEdge = Math.min(viewfinderWidth, viewfinderHeight);
            const edge = Math.floor(minEdge * 0.72);
            return { width: Math.max(edge, 180), height: Math.max(edge, 180) };
          },
          aspectRatio: 1.0,
        };

        const onScanSuccess = (decodedText: string) => {
          if (isHandlingScanRef.current) return;
          isHandlingScanRef.current = true;

          onCheckIn(decodedText, 'qr');

          // Pause slightly before allowing next scan to prevent rapid duplicate scans
          setTimeout(() => {
            isHandlingScanRef.current = false;
          }, 1800);
        };

        try {
          await scanner.start({ facingMode }, qrConfig, onScanSuccess, () => {});
        } catch (firstErr: unknown) {
          console.warn('Initial camera facingMode failed, trying fallback video constraints:', firstErr);
          // Fallback: try default video camera without facingMode constraint
          await scanner.start(
            { facingMode: facingMode === 'environment' ? 'user' : 'environment' },
            qrConfig,
            onScanSuccess,
            () => {}
          );
        }

        if (isMounted) {
          setIsScanningActive(true);
          // Check available cameras in the background without blocking scanner start
          Html5Qrcode.getCameras()
            .then((devices) => {
              if (devices && devices.length > 1 && isMounted) {
                setHasMultipleCameras(true);
              }
            })
            .catch(() => {});
        }
      } catch (err: unknown) {
        if (!isMounted) return;
        const errMsg = err instanceof Error ? err.message : String(err);
        console.warn('Camera start info:', errMsg);

        if (
          errMsg.includes('Permission dismissed') ||
          errMsg.includes('NotAllowedError') ||
          errMsg.includes('Permission denied') ||
          errMsg.includes('dismissed')
        ) {
          setCameraError(
            'Quyền truy cập Camera chưa được cấp hoặc hộp thoại quyền bị đóng. Bạn có thể nhấn nút "Thử lại", hoặc dùng tính năng "Chụp ảnh QR / Nhập tay".'
          );
        } else if (errMsg.includes('NotFoundError') || errMsg.includes('DevicesNotFoundError')) {
          setCameraError(
            'Không tìm thấy thiết bị Camera trên máy này. Vui lòng sử dụng tính năng tải ảnh QR hoặc nhập MSSV thủ công.'
          );
        } else {
          setCameraError(
            'Không thể kết nối với Camera. Vui lòng kiểm tra quyền trong trình duyệt hoặc sử dụng ô Nhập MSSV thủ công.'
          );
        }
        setIsScanningActive(false);
      }
    }, 200);

    return () => {
      isMounted = false;
      clearTimeout(timer);
      if (html5QrCodeRef.current) {
        try {
          if (html5QrCodeRef.current.isScanning) {
            html5QrCodeRef.current.stop().then(() => html5QrCodeRef.current?.clear()).catch(() => {});
          } else {
            html5QrCodeRef.current.clear();
          }
        } catch {
          // Ignore unmount error
        }
      }
    };
  }, [isScannerOpen, facingMode, retryKey]);

  const handleCloseScanner = () => {
    setIsScannerOpen(false);
    setCameraError(null);
    if (html5QrCodeRef.current && isScanningActive) {
      html5QrCodeRef.current
        .stop()
        .then(() => {
          html5QrCodeRef.current?.clear();
          setIsScanningActive(false);
        })
        .catch(() => setIsScanningActive(false));
    }
  };

  const handleRetryCamera = () => {
    setCameraError(null);
    setRetryKey((k) => k + 1);
  };

  const handleSwitchCamera = async () => {
    if (!isScanningActive || !html5QrCodeRef.current) return;
    try {
      await html5QrCodeRef.current.stop();
      setIsScanningActive(false);
      setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
    } catch (e) {
      console.warn('Switch camera error:', e);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const html5QrCode = new Html5Qrcode('qr-file-detector-hidden');
      const result = await html5QrCode.scanFile(file, true);
      onCheckIn(result, 'qr');
      html5QrCode.clear();
      if (isScannerOpen) {
        handleCloseScanner();
      }
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch {
      alert('Không nhận diện được mã QR từ hình ảnh này. Vui lòng chụp rõ nét hoặc vuông góc với mã QR!');
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleMssvChange = (val: string) => {
    setManualCode(val);
    const clean = val.trim().toUpperCase();
    if (clean.length >= 4) {
      const matched = findStudentByMssv(clean);
      if (matched) {
        if (!manualName) {
          setManualName(matched.name);
        }
        if (matched.className === 'LỚP 1' || matched.className === 'LỚP 2' || matched.className === 'LỚP 3') {
          setSelectedClass(matched.className as AdvisorClass);
        }
      }
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    onCheckIn(manualCode.trim(), 'manual', {
      name: manualName.trim() || undefined,
      className: selectedClass,
    });
    setManualCode('');
    setManualName('');
  };

  return (
    <div className="space-y-4">
      {/* Hidden container for file-based QR decoding */}
      <div id="qr-file-detector-hidden" className="hidden" />

      {/* Main Action Box */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/90 shadow-sm relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Nút Mở Camera quét QR */}
          <button
            type="button"
            onClick={() => setIsScannerOpen(true)}
            className="flex-1 bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:from-emerald-700 hover:to-teal-700 active:scale-[0.98] text-white font-semibold py-3.5 px-5 rounded-xl shadow-md shadow-emerald-500/20 flex items-center justify-center gap-2.5 transition group"
          >
            <div className="p-1 rounded-lg bg-white/20 group-hover:scale-110 transition-transform">
              <Camera className="w-5 h-5" />
            </div>
            <span className="text-base tracking-wide">Mở Camera quét QR</span>
          </button>

          {/* Nút tải ảnh quét dự phòng */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="sm:w-auto px-4 py-3 bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 font-medium rounded-xl text-sm flex items-center justify-center gap-2 border border-slate-200 transition"
            title="Tải ảnh QR từ thiết bị nếu camera không khả dụng"
          >
            <Upload className="w-4 h-4 text-slate-500" />
            <span className="sm:inline">Quét từ ảnh</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileUpload}
          />
        </div>

        {/* Ô Nhập MSSV, Họ và tên & Nút chọn 1 trong 3 lớp cố vấn */}
        <div className="mt-4 pt-4 border-t border-slate-100 space-y-3">
          {/* Nút chọn 1 trong 3 lớp: LỚP 1, LỚP 2, LỚP 3 */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-100/90">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-950">
              <Users className="w-3.5 h-3.5 text-emerald-700" />
              <span>Chọn lớp cố vấn:</span>
            </div>

            <div className="grid grid-cols-3 gap-1.5 sm:w-auto">
              {ADVISOR_CLASSES.map((cls) => {
                const isActive = selectedClass === cls;
                return (
                  <button
                    key={cls}
                    type="button"
                    onClick={() => setSelectedClass(cls)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 border active:scale-95 ${
                      isActive
                        ? 'bg-emerald-800 text-white border-emerald-800 shadow-xs'
                        : 'bg-white text-slate-700 hover:bg-slate-100 border-slate-200'
                    }`}
                  >
                    <span
                      className={`w-2 h-2 rounded-full ${
                        isActive ? 'bg-emerald-300' : 'bg-slate-300'
                      }`}
                    />
                    <span>{cls}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <form onSubmit={handleManualSubmit} className="space-y-2.5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {/* Ô Nhập MSSV */}
              <div className="relative">
                <input
                  type="text"
                  value={manualCode}
                  onChange={(e) => handleMssvChange(e.target.value)}
                  placeholder="Mã số sinh viên (MSSV)..."
                  className="w-full pl-3.5 pr-8 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 font-mono font-medium text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition uppercase"
                />
                {manualCode && (
                  <button
                    type="button"
                    onClick={() => setManualCode('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs p-1"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Ô Nhập Họ và tên */}
              <div className="relative">
                <input
                  type="text"
                  value={manualName}
                  onChange={(e) => setManualName(e.target.value)}
                  placeholder="Họ và tên sinh viên (VD: Nguyễn Văn An)..."
                  className="w-full pl-3.5 pr-8 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 font-medium text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
                />
                {manualName && (
                  <button
                    type="button"
                    onClick={() => setManualName('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs p-1"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
              <p className="text-[11px] text-slate-500 flex items-center gap-1.5 truncate">
                <Info className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                <span>Ghi nhận điểm danh vào <strong className="text-emerald-800 font-bold">{selectedClass}</strong></span>
              </p>

              <button
                type="submit"
                disabled={!manualCode.trim()}
                className="w-full sm:w-auto px-5 py-2.5 bg-emerald-800 hover:bg-emerald-700 disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed text-white font-semibold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 transition active:scale-95 shadow-sm shadow-emerald-950/10 flex-shrink-0"
              >
                <Send className="w-4 h-4" />
                <span>Điểm danh</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* FEEDBACK BANNER: Thành công (Xanh lá) hoặc Trùng lặp / Lỗi (Đỏ) */}
      {feedback && (
        <div
          className={`rounded-2xl p-4 border transition-all animate-in fade-in slide-in-from-top-2 duration-300 shadow-md ${
            feedback.type === 'success'
              ? 'bg-emerald-50 border-emerald-300/80 text-emerald-900 shadow-emerald-950/5'
              : feedback.type === 'duplicate'
              ? 'bg-rose-50 border-rose-400 text-rose-900 shadow-rose-950/5 ring-2 ring-rose-300/50'
              : 'bg-amber-50 border-amber-300 text-amber-900'
          }`}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div
                className={`p-2 rounded-xl mt-0.5 flex-shrink-0 ${
                  feedback.type === 'success'
                    ? 'bg-emerald-600 text-white'
                    : feedback.type === 'duplicate'
                    ? 'bg-rose-600 text-white animate-bounce'
                    : 'bg-amber-600 text-white'
                }`}
              >
                {feedback.type === 'success' ? (
                  <CheckCircle2 className="w-5 h-5" />
                ) : (
                  <AlertCircle className="w-5 h-5" />
                )}
              </div>

              <div>
                <h4 className="font-bold text-sm sm:text-base tracking-tight">
                  {feedback.message}
                </h4>
                
                <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
                  <span className="font-mono font-bold bg-white/70 px-2 py-0.5 rounded border border-black/10">
                    MSSV: {feedback.mssv}
                  </span>
                  {feedback.attendee?.name && (
                    <span className="font-medium text-slate-700">
                      Họ tên: <strong className="text-slate-900">{feedback.attendee.name}</strong>
                    </span>
                  )}
                  {feedback.attendee?.className && (
                    <span className="text-slate-600">
                      Lớp: {feedback.attendee.className}
                    </span>
                  )}
                  {feedback.time && (
                    <span className="text-slate-500">
                      Thời gian: {feedback.time}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <button
              onClick={onClearFeedback}
              className="text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-black/5 transition"
              title="Đóng thông báo"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* MODAL SCANNER: Giao diện quét Camera toàn màn hình chuẩn Mobile */}
      {isScannerOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-between p-4 sm:p-6 animate-in fade-in duration-200">
          {/* Header modal quét */}
          <div className="w-full max-w-md flex items-center justify-between text-white pb-3">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-semibold text-sm sm:text-base">Camera quét mã QR</span>
            </div>

            <div className="flex items-center gap-2">
              {hasMultipleCameras && (
                <button
                  onClick={handleSwitchCamera}
                  className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
                  title="Đổi camera trước/sau"
                >
                  <SwitchCamera className="w-5 h-5" />
                </button>
              )}
              <button
                onClick={handleCloseScanner}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
                title="Đóng camera"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Vùng xem trước Camera & Khung quét */}
          <div className="w-full max-w-sm flex-1 flex flex-col items-center justify-center my-auto">
            {cameraError ? (
              <div className="bg-slate-900/95 border border-slate-700/80 p-5 sm:p-6 rounded-3xl text-center text-white max-w-sm shadow-2xl space-y-4 animate-in zoom-in-95 duration-200">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
                  <Camera className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-base text-white mb-1">Cấp quyền Camera</h4>
                  <p className="text-xs text-slate-300 leading-relaxed">{cameraError}</p>
                </div>
                <div className="space-y-2 pt-2">
                  <button
                    onClick={handleRetryCamera}
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 active:scale-98 text-white rounded-xl font-semibold text-xs transition flex items-center justify-center gap-2 shadow-md shadow-blue-600/30"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Thử lại mở Camera</span>
                  </button>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-600 active:scale-98 text-white rounded-xl font-semibold text-xs transition flex items-center justify-center gap-2 shadow-sm"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Chụp / Tải ảnh mã QR</span>
                  </button>
                  <button
                    onClick={handleCloseScanner}
                    className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium text-xs transition"
                  >
                    Đóng & Nhập MSSV thủ công
                  </button>
                </div>
              </div>
            ) : (
              <div className="relative w-full aspect-square max-w-[340px] rounded-3xl overflow-hidden border-2 border-emerald-400/50 shadow-2xl bg-black">
                {/* HTML5 QR Code viewport container */}
                <div id="qr-reader-viewport" className="w-full h-full object-cover" />

                {/* Laser scan line effect */}
                <div className="scanner-laser absolute left-4 right-4 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_12px_#34d399] pointer-events-none z-10" />

                {/* Corner reticle guides */}
                <div className="absolute top-4 left-4 w-7 h-7 border-t-4 border-l-4 border-emerald-400 rounded-tl-lg pointer-events-none z-10" />
                <div className="absolute top-4 right-4 w-7 h-7 border-t-4 border-r-4 border-emerald-400 rounded-tr-lg pointer-events-none z-10" />
                <div className="absolute bottom-4 left-4 w-7 h-7 border-b-4 border-l-4 border-emerald-400 rounded-bl-lg pointer-events-none z-10" />
                <div className="absolute bottom-4 right-4 w-7 h-7 border-b-4 border-r-4 border-emerald-400 rounded-br-lg pointer-events-none z-10" />
              </div>
            )}

            <p className="text-xs text-slate-300 mt-4 text-center font-medium bg-black/40 px-3 py-1.5 rounded-full border border-white/10">
              Đặt mã QR sinh viên vào giữa khung hình vuông để tự động điểm danh
            </p>
          </div>

          {/* Nút thoát */}
          <div className="w-full max-w-md pt-2">
            <button
              onClick={handleCloseScanner}
              className="w-full py-3 bg-white/15 hover:bg-white/25 active:scale-98 text-white rounded-xl text-sm font-semibold transition"
            >
              Xong / Đóng camera
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
