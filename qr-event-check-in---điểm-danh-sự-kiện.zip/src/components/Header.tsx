import React from 'react';
import { QrCode, Volume2, VolumeX, Sparkles, Settings2 } from 'lucide-react';
import { EventInfo } from '../types/attendance';

interface HeaderProps {
  eventInfo: EventInfo;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenSettings: () => void;
  onOpenQRGenerator: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  eventInfo,
  isMuted,
  onToggleMute,
  onOpenSettings,
  onOpenQRGenerator,
}) => {
  return (
    <header className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-800 text-white shadow-lg sticky top-0 z-30">
      <div className="max-w-4xl mx-auto px-4 py-3 sm:py-4">
        <div className="flex items-center justify-between gap-3">
          {/* Logo & Event Title */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-tr from-emerald-400 to-teal-300 p-0.5 shadow-md flex-shrink-0 flex items-center justify-center">
              <div className="w-full h-full bg-emerald-950/70 rounded-[10px] flex items-center justify-center">
                <QrCode className="w-6 h-6 text-emerald-300" />
              </div>
            </div>
            
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] sm:text-xs font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-800/80 text-emerald-100 border border-emerald-600/50 truncate max-w-full">
                  {eventInfo.organization || 'KHOA MÔI TRƯỜNG VÀ TÀI NGUYÊN THIÊN NHIÊN'}
                </span>
                <span className="hidden md:inline-flex text-[11px] text-emerald-200/80 flex-shrink-0">
                  • {eventInfo.date}
                </span>
              </div>
              <h1 className="text-sm sm:text-base md:text-lg font-bold tracking-tight text-white drop-shadow-sm leading-snug mt-0.5 line-clamp-2">
                {eventInfo.name}
              </h1>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
            {/* Tạo mã QR mẫu để test */}
            <button
              onClick={onOpenQRGenerator}
              className="px-2.5 py-1.5 sm:px-3 sm:py-2 text-xs font-medium rounded-lg bg-emerald-800/80 hover:bg-emerald-700 border border-emerald-600/40 text-emerald-100 flex items-center gap-1.5 transition active:scale-95 shadow-sm"
              title="Tạo mã QR mẫu để test quét"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span className="hidden sm:inline">Mã QR mẫu</span>
            </button>

            {/* Bật/Tắt âm thanh beep */}
            <button
              onClick={onToggleMute}
              className={`p-2 rounded-lg text-xs font-medium border transition active:scale-95 ${
                isMuted
                  ? 'bg-rose-900/60 border-rose-700/50 text-rose-200 hover:bg-rose-900'
                  : 'bg-emerald-800/80 border-emerald-600/40 text-emerald-100 hover:bg-emerald-700'
              }`}
              title={isMuted ? 'Bật âm thanh báo' : 'Tắt âm thanh báo'}
              aria-label="Cài đặt âm thanh"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-300" />}
            </button>

            {/* Cài đặt sự kiện */}
            <button
              onClick={onOpenSettings}
              className="p-2 rounded-lg bg-emerald-800/80 hover:bg-emerald-700 border border-emerald-600/40 text-emerald-100 transition active:scale-95"
              title="Cài đặt thông tin sự kiện"
              aria-label="Cài đặt sự kiện"
            >
              <Settings2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
