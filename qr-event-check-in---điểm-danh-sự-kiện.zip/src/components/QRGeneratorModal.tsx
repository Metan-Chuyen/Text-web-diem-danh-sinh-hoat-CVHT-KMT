import React, { useState, useEffect } from 'react';
import { X, QrCode, Download, Copy, Check, Sparkles } from 'lucide-react';
import QRCode from 'qrcode';
import { DEFAULT_STUDENT_DIRECTORY } from '../utils/storage';

interface QRGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onQuickCheckIn: (mssv: string) => void;
}

export const QRGeneratorModal: React.FC<QRGeneratorModalProps> = ({
  isOpen,
  onClose,
  onQuickCheckIn,
}) => {
  const [selectedStudentMssv, setSelectedStudentMssv] = useState<string>('B2101234');
  const [customInput, setCustomInput] = useState<string>('B2101234');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (!customInput.trim()) return;
    QRCode.toDataURL(customInput.trim().toUpperCase(), {
      width: 320,
      margin: 2,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error(err));
  }, [customInput]);

  if (!isOpen) return null;

  const currentStudent = DEFAULT_STUDENT_DIRECTORY.find(
    (s) => s.mssv.toUpperCase() === customInput.trim().toUpperCase()
  );

  const handleSelectPreset = (mssv: string) => {
    setSelectedStudentMssv(mssv);
    setCustomInput(mssv);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(customInput.trim().toUpperCase());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 relative">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2 text-emerald-900">
            <div className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <Sparkles className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-base sm:text-lg">Tạo Mã QR Thử Nghiệm</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-4">
          <p className="text-xs text-slate-500">
            Sử dụng công cụ này để tạo mã QR thử tính năng quét bằng camera điện thoại hoặc nhấn "Điểm danh nhanh" để thử nghiệm.
          </p>

          {/* Preset Student Buttons */}
          <div>
            <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">
              Chọn nhanh sinh viên mẫu:
            </label>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1 bg-slate-50 rounded-xl border border-slate-200/80">
              {DEFAULT_STUDENT_DIRECTORY.map((s) => (
                <button
                  key={s.mssv}
                  onClick={() => handleSelectPreset(s.mssv)}
                  className={`text-xs px-2.5 py-1 rounded-lg font-mono font-medium transition ${
                    customInput.toUpperCase() === s.mssv.toUpperCase()
                      ? 'bg-emerald-800 text-white shadow-xs'
                      : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
                  }`}
                >
                  {s.mssv} ({s.name.split(' ').slice(-1)[0]})
                </button>
              ))}
            </div>
          </div>

          {/* Input MSSV / Code */}
          <div>
            <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
              Hoặc nhập MSSV bất kỳ:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                placeholder="Nhập MSSV (VD: B2101234)"
                className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-bold uppercase focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <button
                onClick={handleCopy}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1 border border-slate-200"
                title="Sao chép MSSV"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* QR Code Canvas / Image Display */}
          <div className="bg-slate-50 border border-slate-200/90 rounded-2xl p-4 flex flex-col items-center justify-center">
            {qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt={`QR Code for ${customInput}`}
                className="w-48 h-48 rounded-xl shadow-xs border border-white bg-white p-2"
              />
            ) : (
              <div className="w-48 h-48 bg-slate-200 rounded-xl flex items-center justify-center text-slate-400">
                <QrCode className="w-12 h-12" />
              </div>
            )}

            <div className="mt-2 text-center">
              <span className="font-mono font-bold text-sm text-slate-900 tracking-wider">
                {customInput.toUpperCase() || 'CHƯA NHẬP MÃ'}
              </span>
              {currentStudent && (
                <p className="text-xs text-emerald-700 font-semibold mt-0.5">
                  {currentStudent.name} • {currentStudent.className}
                </p>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={() => {
                onQuickCheckIn(customInput.trim().toUpperCase());
                onClose();
              }}
              className="flex-1 py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold transition active:scale-95 shadow-sm shadow-emerald-950/10"
            >
              Điểm danh thử mã này
            </button>

            {qrDataUrl && (
              <a
                href={qrDataUrl}
                download={`QR_${customInput.toUpperCase()}.png`}
                className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-slate-200 transition"
                title="Tải ảnh QR về máy"
              >
                <Download className="w-4 h-4" />
                <span>Tải ảnh QR</span>
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
