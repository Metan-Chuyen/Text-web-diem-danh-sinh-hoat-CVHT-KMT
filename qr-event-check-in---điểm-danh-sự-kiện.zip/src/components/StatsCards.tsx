import React from 'react';
import { Users, QrCode, Keyboard, Clock } from 'lucide-react';
import { Attendee } from '../types/attendance';

interface StatsCardsProps {
  attendees: Attendee[];
}

export const StatsCards: React.FC<StatsCardsProps> = ({ attendees }) => {
  const total = attendees.length;
  const qrCount = attendees.filter((a) => a.method === 'qr').length;
  const manualCount = attendees.filter((a) => a.method === 'manual').length;
  const latest = attendees[0];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
      {/* Thẻ Tổng số đã điểm danh (Nổi bật nhất) */}
      <div className="col-span-2 sm:col-span-1 bg-gradient-to-br from-emerald-800 to-teal-900 rounded-2xl p-4 text-white shadow-md shadow-emerald-950/10 border border-emerald-700/50 relative overflow-hidden">
        <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-emerald-400/10 rounded-full blur-xl pointer-events-none" />
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs font-semibold text-emerald-100 uppercase tracking-wider">
            Tổng đã điểm danh
          </span>
          <div className="p-1.5 rounded-lg bg-emerald-700/50 text-emerald-200">
            <Users className="w-4 h-4" />
          </div>
        </div>
        <div className="flex items-baseline gap-1.5">
          <span className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
            {total}
          </span>
          <span className="text-xs font-medium text-emerald-100">người</span>
        </div>
        <p className="text-[11px] text-emerald-200/80 mt-1 truncate">
          Cập nhật tức thời (Real-time)
        </p>
      </div>

      {/* Quét qua mã QR */}
      <div className="bg-white rounded-2xl p-3.5 sm:p-4 border border-slate-200/80 shadow-sm hover:border-emerald-300 transition">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[11px] sm:text-xs font-semibold text-slate-500 uppercase">
            Quét mã QR
          </span>
          <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600">
            <QrCode className="w-4 h-4" />
          </div>
        </div>
        <div className="flex items-baseline gap-1.5">
          <span className="text-2xl sm:text-3xl font-bold text-slate-800">
            {qrCount}
          </span>
          <span className="text-[11px] text-slate-400">lượt</span>
        </div>
        <p className="text-[11px] text-emerald-600 font-medium mt-1">
          {total > 0 ? `${Math.round((qrCount / total) * 100)}% tổng số` : '0%'}
        </p>
      </div>

      {/* Nhập thủ công */}
      <div className="bg-white rounded-2xl p-3.5 sm:p-4 border border-slate-200/80 shadow-sm hover:border-emerald-300 transition">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[11px] sm:text-xs font-semibold text-slate-500 uppercase">
            Nhập thủ công
          </span>
          <div className="p-1.5 rounded-lg bg-amber-50 text-amber-600">
            <Keyboard className="w-4 h-4" />
          </div>
        </div>
        <div className="flex items-baseline gap-1.5">
          <span className="text-2xl sm:text-3xl font-bold text-slate-800">
            {manualCount}
          </span>
          <span className="text-[11px] text-slate-400">lượt</span>
        </div>
        <p className="text-[11px] text-amber-600 font-medium mt-1">
          {total > 0 ? `${Math.round((manualCount / total) * 100)}% tổng số` : '0%'}
        </p>
      </div>

      {/* Gần nhất */}
      <div className="col-span-2 sm:col-span-1 bg-white rounded-2xl p-3.5 sm:p-4 border border-slate-200/80 shadow-sm hover:border-emerald-300 transition">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[11px] sm:text-xs font-semibold text-slate-500 uppercase">
            Mới điểm danh
          </span>
          <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
            <Clock className="w-4 h-4" />
          </div>
        </div>
        {latest ? (
          <div>
            <div className="font-bold text-slate-800 text-sm sm:text-base truncate font-mono">
              {latest.mssv}
            </div>
            <div className="text-[11px] text-slate-500 truncate">
              {latest.name || latest.checkInTime.split(' - ')[0]}
            </div>
          </div>
        ) : (
          <div className="text-xs text-slate-400 py-1">Chưa có dữ liệu</div>
        )}
      </div>
    </div>
  );
};
