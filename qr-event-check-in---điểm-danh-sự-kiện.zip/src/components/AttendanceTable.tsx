import React, { useState, useMemo } from 'react';
import { Search, FileSpreadsheet, Download, Trash2, CheckCircle2, UserCheck, Filter, ArrowUpDown } from 'lucide-react';
import { Attendee, EventInfo } from '../types/attendance';
import { exportToExcel, exportToCSV } from '../utils/excel';

interface AttendanceTableProps {
  attendees: Attendee[];
  eventInfo: EventInfo;
  onDeleteAttendee: (id: string) => void;
  onClearAll: () => void;
}

export const AttendanceTable: React.FC<AttendanceTableProps> = ({
  attendees,
  eventInfo,
  onDeleteAttendee,
  onClearAll,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterClass, setFilterClass] = useState<'all' | 'LỚP 1' | 'LỚP 2' | 'LỚP 3'>('all');
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);

  // Lọc theo tìm kiếm MSSV / Tên và bộ lọc theo Lớp cố vấn
  const filteredAttendees = useMemo(() => {
    return attendees.filter((item) => {
      const q = searchQuery.trim().toLowerCase();
      const matchQuery =
        !q ||
        item.mssv.toLowerCase().includes(q) ||
        (item.name && item.name.toLowerCase().includes(q)) ||
        (item.className && item.className.toLowerCase().includes(q));

      const matchClass = filterClass === 'all' || item.className === filterClass;
      return matchQuery && matchClass;
    });
  }, [attendees, searchQuery, filterClass]);

  // Đếm nhanh số sinh viên đã điểm danh theo từng lớp
  const classCounts = useMemo(() => {
    return {
      'LỚP 1': attendees.filter((a) => a.className === 'LỚP 1').length,
      'LỚP 2': attendees.filter((a) => a.className === 'LỚP 2').length,
      'LỚP 3': attendees.filter((a) => a.className === 'LỚP 3').length,
    };
  }, [attendees]);

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
      {/* Table Top Controls & Search Bar */}
      <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col gap-3.5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-slate-800 text-base sm:text-lg flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-emerald-700" />
              <span>Danh sách đã điểm danh</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                {attendees.length}
              </span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Người mới quét điểm danh sẽ tự động xuất hiện ở đầu bảng
            </p>
          </div>

          {/* Action buttons: Xuất file Excel / CSV */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => exportToExcel(attendees, eventInfo)}
              disabled={attendees.length === 0}
              className="flex-1 sm:flex-none px-3.5 py-2.5 bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed text-white font-semibold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 transition active:scale-95 shadow-sm"
              title="Tải về file Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
              <span>Xuất file Excel</span>
            </button>

            <button
              onClick={() => exportToCSV(attendees, eventInfo)}
              disabled={attendees.length === 0}
              className="px-3 py-2.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 disabled:cursor-not-allowed text-slate-700 font-medium text-xs sm:text-sm rounded-xl flex items-center justify-center gap-1.5 border border-slate-200 transition"
              title="Xuất file CSV (UTF-8)"
            >
              <Download className="w-4 h-4 text-slate-500" />
              <span className="hidden sm:inline">CSV</span>
            </button>

            {attendees.length > 0 && (
              <button
                onClick={() => setConfirmClearOpen(true)}
                className="p-2.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition border border-transparent hover:border-rose-200"
                title="Xóa toàn bộ danh sách điểm danh"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Ô Tìm kiếm (Search) theo MSSV và Bộ lọc */}
        <div className="flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm kiếm theo MSSV hoặc Họ tên..."
              className="w-full pl-9 pr-9 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs p-1"
              >
                ✕
              </button>
            )}
          </div>

          {/* Quick Filter buttons theo 3 lớp cố vấn */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs flex-shrink-0 overflow-x-auto max-w-full">
            <button
              onClick={() => setFilterClass('all')}
              className={`px-3 py-1.5 rounded-lg font-medium transition whitespace-nowrap ${
                filterClass === 'all'
                  ? 'bg-white text-emerald-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tất cả ({attendees.length})
            </button>
            {(['LỚP 1', 'LỚP 2', 'LỚP 3'] as const).map((cls) => (
              <button
                key={cls}
                onClick={() => setFilterClass(cls)}
                className={`px-2.5 py-1.5 rounded-lg font-medium transition whitespace-nowrap ${
                  filterClass === cls
                    ? 'bg-white text-emerald-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cls} ({classCounts[cls]})
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Table for Desktop & Tablet / Card list for Mobile */}
      {filteredAttendees.length === 0 ? (
        <div className="p-8 sm:p-12 text-center">
          <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-3 text-slate-400">
            <Search className="w-6 h-6" />
          </div>
          <h4 className="font-semibold text-slate-700 text-sm sm:text-base">
            {searchQuery || filterClass !== 'all' ? 'Không tìm thấy kết quả phù hợp' : 'Chưa có ai điểm danh'}
          </h4>
          <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
            {searchQuery
              ? `Không có bản ghi nào khớp với từ khóa "${searchQuery}"`
              : filterClass !== 'all'
              ? `Chưa có sinh viên nào thuộc ${filterClass} được điểm danh.`
              : 'Hãy mở camera quét mã QR hoặc nhập MSSV thủ công ở phía trên để bắt đầu.'}
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 text-[11px] sm:text-xs font-semibold uppercase tracking-wider text-slate-500 border-b border-slate-200">
                <th className="py-3 px-3 sm:px-4 w-12 text-center">STT</th>
                <th className="py-3 px-3 sm:px-4">Mã số (MSSV)</th>
                <th className="py-3 px-3 sm:px-4 hidden md:table-cell">Họ và tên & Lớp</th>
                <th className="py-3 px-3 sm:px-4">Thời gian điểm danh</th>
                <th className="py-3 px-3 sm:px-4">Trạng thái</th>
                <th className="py-3 px-3 sm:px-4 w-12 text-center">Xóa</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
              {filteredAttendees.map((item, index) => {
                const isNewest = index === 0 && !searchQuery && filterClass === 'all';
                return (
                  <tr
                    key={item.id}
                    className={`transition-colors hover:bg-emerald-50/40 group ${
                      isNewest ? 'bg-emerald-50/30' : ''
                    }`}
                  >
                    {/* STT */}
                    <td className="py-3 px-3 sm:px-4 text-center font-mono text-slate-400 text-xs">
                      {index + 1}
                    </td>

                    {/* Mã số (MSSV) */}
                    <td className="py-3 px-3 sm:px-4">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-emerald-950 text-sm">
                          {item.mssv}
                        </span>
                        {/* Phương thức quét / nhập */}
                        <span
                          className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${
                            item.method === 'qr'
                              ? 'bg-emerald-100/80 text-emerald-800'
                              : 'bg-amber-100/70 text-amber-800'
                          }`}
                        >
                          {item.method === 'qr' ? 'QR' : 'Tay'}
                        </span>
                      </div>
                      {/* Tên sinh viên & Lớp hiển thị phụ trên màn hình nhỏ */}
                      {(item.name || item.className) && (
                        <div className="md:hidden flex items-center gap-1.5 text-[11px] text-slate-600 font-medium truncate mt-0.5">
                          {item.name && <span>{item.name}</span>}
                          {item.className && (
                            <span className="font-bold text-[10px] px-1.5 py-0.2 bg-emerald-100 text-emerald-800 rounded">
                              {item.className}
                            </span>
                          )}
                        </div>
                      )}
                    </td>

                    {/* Họ và tên & Lớp (Desktop/Tablet) */}
                    <td className="py-3 px-3 sm:px-4 hidden md:table-cell">
                      <div className="font-semibold text-slate-800 flex items-center gap-2">
                        <span>{item.name || <span className="text-slate-400 font-normal italic">Chưa cập nhật tên</span>}</span>
                        {item.className && (
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                            item.className === 'LỚP 1'
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : item.className === 'LỚP 2'
                              ? 'bg-teal-100 text-teal-800 border-teal-300'
                              : 'bg-green-100 text-green-800 border-green-300'
                          }`}>
                            {item.className}
                          </span>
                        )}
                      </div>
                      {item.department && (
                        <div className="text-[11px] text-slate-500">
                          {item.department}
                        </div>
                      )}
                    </td>

                    {/* Thời gian điểm danh */}
                    <td className="py-3 px-3 sm:px-4 whitespace-nowrap text-slate-600 font-mono text-xs">
                      {item.checkInTime}
                    </td>

                    {/* Trạng thái */}
                    <td className="py-3 px-3 sm:px-4 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        <span>{item.status || 'Hợp lệ'}</span>
                      </span>
                    </td>

                    {/* Nút Xóa bản ghi nếu nhập nhầm */}
                    <td className="py-3 px-3 sm:px-4 text-center">
                      <button
                        onClick={() => onDeleteAttendee(item.id)}
                        className="text-slate-300 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50 transition"
                        title="Xóa lượt điểm danh này"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Confirmation Dialog for Clearing All */}
      {confirmClearOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150">
            <h4 className="font-bold text-slate-900 text-base mb-2">
              Xóa toàn bộ danh sách điểm danh?
            </h4>
            <p className="text-xs text-slate-600 mb-5 leading-relaxed">
              Thao tác này sẽ đặt lại danh sách điểm danh về 0. Bạn nên bấm <strong>Xuất file Excel</strong> trước khi xóa để lưu trữ.
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setConfirmClearOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
              >
                Hủy
              </button>
              <button
                onClick={() => {
                  onClearAll();
                  setConfirmClearOpen(false);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 text-white hover:bg-rose-700 transition"
              >
                Đồng ý xóa
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
