export interface Attendee {
  id: string;
  mssv: string;
  name?: string;
  department?: string;
  className?: string;
  checkInTime: string; // e.g. "09:30:15 - 03/11/2026"
  timestamp: number;
  method: 'qr' | 'manual';
  status: 'Thành công' | 'Hợp lệ' | 'Trễ';
  note?: string;
}

export interface StudentProfile {
  mssv: string;
  name: string;
  className: string;
  faculty: string;
  email?: string;
}

export interface EventInfo {
  name: string;
  organization: string;
  date: string;
  location: string;
}

export type ScanFeedback = {
  type: 'success' | 'duplicate' | 'error';
  message: string;
  mssv: string;
  time?: string;
  attendee?: Attendee;
} | null;
