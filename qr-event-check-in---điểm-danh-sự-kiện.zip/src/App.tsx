/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { Header } from './components/Header';
import { StatsCards } from './components/StatsCards';
import { ScanArea } from './components/ScanArea';
import { AttendanceTable } from './components/AttendanceTable';
import { QRGeneratorModal } from './components/QRGeneratorModal';
import { EventSettingsModal } from './components/EventSettingsModal';
import { Attendee, EventInfo, ScanFeedback } from './types/attendance';
import { soundManager } from './utils/audio';
import {
  getStoredAttendees,
  saveStoredAttendees,
  getStoredEventInfo,
  saveStoredEventInfo,
  findStudentByMssv,
  INITIAL_SAMPLE_ATTENDEES,
  DEFAULT_EVENT_INFO,
} from './utils/storage';

export default function App() {
  const [attendees, setAttendees] = useState<Attendee[]>(() => getStoredAttendees());
  const [eventInfo, setEventInfo] = useState<EventInfo>(() => getStoredEventInfo());
  const [feedback, setFeedback] = useState<ScanFeedback>(null);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isQRModalOpen, setIsQRModalOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    saveStoredAttendees(attendees);
  }, [attendees]);

  useEffect(() => {
    saveStoredEventInfo(eventInfo);
  }, [eventInfo]);

  // Clean extraction of student code from QR payloads
  const parseRawStudentCode = (raw: string): string => {
    let clean = raw.trim();

    // Check if JSON
    if (clean.startsWith('{') && clean.endsWith('}')) {
      try {
        const parsed = JSON.parse(clean);
        if (parsed.mssv) return String(parsed.mssv).trim();
        if (parsed.id) return String(parsed.id).trim();
        if (parsed.code) return String(parsed.code).trim();
      } catch {
        // Continue to regex checks
      }
    }

    // Check if URL with query parameter (e.g. ?mssv=B2101234 or ?id=B2101234)
    if (clean.includes('http://') || clean.includes('https://')) {
      try {
        const url = new URL(clean);
        const mssvParam = url.searchParams.get('mssv') || url.searchParams.get('id') || url.searchParams.get('code');
        if (mssvParam) return mssvParam.trim();
        // If path ends with ID
        const segments = url.pathname.split('/').filter(Boolean);
        if (segments.length > 0) {
          const last = segments[segments.length - 1];
          if (/^[a-zA-Z0-9_-]{3,20}$/.test(last)) {
            return last;
          }
        }
      } catch {
        // Ignore URL parse error
      }
    }

    // Check if "MSSV: B2101234" or "ID: 1234"
    const prefixMatch = clean.match(/^(?:MSSV|ID|MÃ SỐ|MA SO)[\s:]+(.+)$/i);
    if (prefixMatch && prefixMatch[1]) {
      clean = prefixMatch[1].trim();
    }

    return clean;
  };

  // Format current timestamp
  const formatCurrentTime = (): string => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    });
    const dateStr = now.toLocaleDateString('vi-VN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
    return `${timeStr} - ${dateStr}`;
  };

  // Core Check-In Handler
  const handleCheckIn = useCallback(
    (
      rawCode: string,
      method: 'qr' | 'manual',
      manualDetails?: { name?: string; className?: string }
    ) => {
      const parsedMssv = parseRawStudentCode(rawCode).toUpperCase();

      if (!parsedMssv) {
        soundManager.playErrorBuzz();
        soundManager.vibrate([150, 80, 150]);
        setFeedback({
          type: 'error',
          message: 'Mã quét không hợp lệ hoặc bị trống!',
          mssv: rawCode,
        });
        return;
      }

      // 1. DUPLICATE CHECK: Kiểm tra trùng lặp
      const existing = attendees.find((a) => a.mssv.toUpperCase() === parsedMssv);
      if (existing) {
        soundManager.playErrorBuzz();
        soundManager.vibrate([200, 100, 200]);

        setFeedback({
          type: 'duplicate',
          message: 'Mã này đã được điểm danh trước đó!',
          mssv: parsedMssv,
          time: existing.checkInTime,
          attendee: existing,
        });
        return;
      }

      // 2. SUCCESS CHECK-IN
      soundManager.playSuccessBeep();
      soundManager.vibrate([90]);

      // Trigger celebratory micro-confetti on milestones or smooth scan
      try {
        confetti({
          particleCount: 25,
          spread: 60,
          origin: { y: 0.25 },
          colors: ['#10b981', '#34d399', '#6ee7b7', '#059669'],
          disableForReducedMotion: true,
        });
      } catch {
        // Ignore if confetti fails
      }

      // Look up student details from directory if available
      const studentProfile = findStudentByMssv(parsedMssv);
      const currentTimeStr = formatCurrentTime();

      const finalName = manualDetails?.name?.trim() || studentProfile?.name;
      const finalClassName = manualDetails?.className?.trim() || studentProfile?.className || 'LỚP 1';

      const newAttendee: Attendee = {
        id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        mssv: parsedMssv,
        name: finalName,
        className: finalClassName,
        department: studentProfile?.faculty || 'Khoa MT & TNTN',
        checkInTime: currentTimeStr,
        timestamp: Date.now(),
        method,
        status: 'Hợp lệ',
      };

      // Tự động chèn lên ĐẦU danh sách (Requirement 3: Danh sách mới điểm danh phải được tự động chèn lên đầu bảng)
      setAttendees((prev) => [newAttendee, ...prev]);

      setFeedback({
        type: 'success',
        message: 'Điểm danh thành công!',
        mssv: parsedMssv,
        time: currentTimeStr,
        attendee: newAttendee,
      });
    },
    [attendees]
  );

  const handleDeleteAttendee = (id: string) => {
    setAttendees((prev) => prev.filter((a) => a.id !== id));
  };

  const handleClearAll = () => {
    setAttendees([]);
    setFeedback(null);
  };

  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    soundManager.isMuted = nextMuted;
  };

  const handleRestoreDefaults = () => {
    setAttendees(INITIAL_SAMPLE_ATTENDEES);
    setEventInfo(DEFAULT_EVENT_INFO);
    setFeedback(null);
  };

  return (
    <div className="min-h-screen bg-[#f7faf8] flex flex-col selection:bg-emerald-600 selection:text-white">
      {/* 1. THANH TIÊU ĐỀ (HEADER) */}
      <Header
        eventInfo={eventInfo}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenQRGenerator={() => setIsQRModalOpen(true)}
      />

      {/* MAIN CONTAINER: Chuẩn Mobile-First, tối ưu mượt mà trên điện thoại */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-3.5 sm:px-4 py-4 sm:py-6 space-y-4 sm:space-y-5">
        {/* THẺ THỐNG KÊ NHANH (REAL-TIME STATS) */}
        <StatsCards attendees={attendees} />

        {/* 2. KHU VỰC QUÉT / NHẬP THÔNG TIN ĐIỂM DANH */}
        <ScanArea
          onCheckIn={handleCheckIn}
          feedback={feedback}
          onClearFeedback={() => setFeedback(null)}
        />

        {/* 3. BẢNG HIỂN THỊ DANH SÁCH ĐÃ ĐIỂM DANH & XUẤT EXCEL */}
        <AttendanceTable
          attendees={attendees}
          eventInfo={eventInfo}
          onDeleteAttendee={handleDeleteAttendee}
          onClearAll={handleClearAll}
        />
      </main>

      {/* MODAL CÀI ĐẶT SỰ KIỆN */}
      <EventSettingsModal
        isOpen={isSettingsOpen}
        eventInfo={eventInfo}
        onSave={(updated) => setEventInfo(updated)}
        onClose={() => setIsSettingsOpen(false)}
        onRestoreDefaults={handleRestoreDefaults}
      />

      {/* MODAL TẠO MÃ QR TEST */}
      <QRGeneratorModal
        isOpen={isQRModalOpen}
        onClose={() => setIsQRModalOpen(false)}
        onQuickCheckIn={(mssv) => handleCheckIn(mssv, 'qr')}
      />

      {/* FOOTER */}
      <footer className="mt-auto py-4 border-t border-slate-200/80 bg-white text-center text-xs text-slate-500">
        <p className="font-medium text-slate-600">
          Hệ thống Điểm danh Sự kiện bằng Mã QR • Mobile-First Check-in
        </p>
        <p className="text-[11px] text-slate-400 mt-0.5">
          Dữ liệu được lưu trữ an toàn trên thiết bị (LocalStorage)
        </p>
      </footer>
    </div>
  );
}
