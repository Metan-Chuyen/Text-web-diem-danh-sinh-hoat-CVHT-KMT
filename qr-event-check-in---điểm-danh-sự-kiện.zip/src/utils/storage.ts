import { Attendee, EventInfo, StudentProfile } from '../types/attendance';

export const STORAGE_KEY_ATTENDEES = 'QR_ATTENDANCE_LIST_V1';
export const STORAGE_KEY_EVENT = 'QR_ATTENDANCE_EVENT_V1';
export const STORAGE_KEY_STUDENTS = 'QR_ATTENDANCE_STUDENTS_V1';

export const ADVISOR_CLASSES = ['LỚP 1', 'LỚP 2', 'LỚP 3'] as const;
export type AdvisorClass = typeof ADVISOR_CLASSES[number];

// Danh sách sinh viên mẫu phổ biến để tự động nhận diện tên khi quét QR
export const DEFAULT_STUDENT_DIRECTORY: StudentProfile[] = [
  { mssv: 'B2101234', name: 'Nguyễn Văn An', className: 'LỚP 1', faculty: 'Khoa MT & TNTN' },
  { mssv: 'B2105678', name: 'Trần Thị Mai Phương', className: 'LỚP 2', faculty: 'Khoa MT & TNTN' },
  { mssv: 'B2203456', name: 'Lê Hoàng Nam', className: 'LỚP 3', faculty: 'Khoa MT & TNTN' },
  { mssv: 'B2208901', name: 'Phạm Minh Tuấn', className: 'LỚP 1', faculty: 'Khoa MT & TNTN' },
  { mssv: 'B2301122', name: 'Đỗ Thảo Vy', className: 'LỚP 2', faculty: 'Khoa MT & TNTN' },
  { mssv: 'B2309988', name: 'Võ Quốc Bảo', className: 'LỚP 3', faculty: 'Khoa MT & TNTN' },
  { mssv: 'B2004567', name: 'Huỳnh Gia Hưng', className: 'LỚP 1', faculty: 'Khoa MT & TNTN' },
  { mssv: 'B2109876', name: 'Ngô Thanh Trúc', className: 'LỚP 2', faculty: 'Khoa MT & TNTN' },
];

export const DEFAULT_EVENT_INFO: EventInfo = {
  name: 'ĐIỂM DANH SINH VIÊN SINH HOẠT CỐ VẤN HỌC TẬP',
  organization: 'KHOA MÔI TRƯỜNG VÀ TÀI NGUYÊN THIÊN NHIÊN',
  date: new Date().toLocaleDateString('vi-VN'),
  location: 'Văn phòng Khoa MT&TNTN',
};

// Khởi tạo một số lượt điểm danh mẫu để người dùng thấy giao diện ngay
export const INITIAL_SAMPLE_ATTENDEES: Attendee[] = [
  {
    id: 'att-1',
    mssv: 'B2101234',
    name: 'Nguyễn Văn An',
    className: 'LỚP 1',
    department: 'Khoa MT & TNTN',
    checkInTime: '08:15:22 - 03/11/2026',
    timestamp: Date.now() - 3600000,
    method: 'qr',
    status: 'Hợp lệ',
  },
  {
    id: 'att-2',
    mssv: 'B2105678',
    name: 'Trần Thị Mai Phương',
    className: 'LỚP 2',
    department: 'Khoa MT & TNTN',
    checkInTime: '08:19:40 - 03/11/2026',
    timestamp: Date.now() - 3200000,
    method: 'qr',
    status: 'Hợp lệ',
  },
  {
    id: 'att-3',
    mssv: 'B2203456',
    name: 'Lê Hoàng Nam',
    className: 'LỚP 3',
    department: 'Khoa MT & TNTN',
    checkInTime: '08:24:11 - 03/11/2026',
    timestamp: Date.now() - 2500000,
    method: 'manual',
    status: 'Hợp lệ',
  },
];

export function getStoredAttendees(): Attendee[] {
  if (typeof window === 'undefined') return INITIAL_SAMPLE_ATTENDEES;
  try {
    const data = localStorage.getItem(STORAGE_KEY_ATTENDEES);
    if (data) {
      return JSON.parse(data);
    }
  } catch (e) {
    console.error('Error reading localStorage attendees:', e);
  }
  return INITIAL_SAMPLE_ATTENDEES;
}

export function saveStoredAttendees(attendees: Attendee[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_ATTENDEES, JSON.stringify(attendees));
  } catch (e) {
    console.error('Error saving localStorage attendees:', e);
  }
}

export function getStoredEventInfo(): EventInfo {
  if (typeof window === 'undefined') return DEFAULT_EVENT_INFO;
  try {
    const data = localStorage.getItem(STORAGE_KEY_EVENT);
    if (data) {
      const parsed = JSON.parse(data);
      if (parsed.name === 'HỘI NGHỊ KHOA HỌC SINH VIÊN 2026') {
        saveStoredEventInfo(DEFAULT_EVENT_INFO);
        return DEFAULT_EVENT_INFO;
      }
      return parsed;
    }
  } catch (e) {
    console.error('Error reading event info:', e);
  }
  return DEFAULT_EVENT_INFO;
}

export function saveStoredEventInfo(event: EventInfo): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_EVENT, JSON.stringify(event));
  } catch (e) {
    console.error('Error saving event info:', e);
  }
}

export function findStudentByMssv(mssv: string): StudentProfile | undefined {
  const cleanMssv = mssv.trim().toUpperCase();
  return DEFAULT_STUDENT_DIRECTORY.find((s) => s.mssv.toUpperCase() === cleanMssv);
}
