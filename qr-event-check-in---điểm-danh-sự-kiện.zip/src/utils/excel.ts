import * as XLSX from 'xlsx';
import { Attendee, EventInfo } from '../types/attendance';

export function exportToExcel(attendees: Attendee[], eventInfo: EventInfo) {
  // Chuẩn bị dữ liệu hiển thị theo đúng thứ tự cột tiếng Việt
  const rows = attendees.map((item, index) => ({
    'STT': index + 1,
    'Mã số (MSSV)': item.mssv,
    'Họ và tên': item.name || 'Chưa cập nhật',
    'Lớp': item.className || 'N/A',
    'Khoa / Đơn vị': item.department || 'N/A',
    'Thời gian điểm danh': item.checkInTime,
    'Hình thức': item.method === 'qr' ? 'Quét mã QR' : 'Nhập thủ công',
    'Trạng thái': item.status,
    'Ghi chú': item.note || '',
  }));

  // Tạo Worksheet
  const worksheet = XLSX.utils.json_to_sheet(rows);

  // Thiết lập độ rộng cột tối ưu
  const colWidths = [
    { wch: 6 },  // STT
    { wch: 16 }, // MSSV
    { wch: 25 }, // Họ tên
    { wch: 14 }, // Lớp
    { wch: 24 }, // Khoa
    { wch: 24 }, // Thời gian
    { wch: 16 }, // Hình thức
    { wch: 14 }, // Trạng thái
    { wch: 20 }, // Ghi chú
  ];
  worksheet['!cols'] = colWidths;

  // Tạo Workbook
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Danh sách điểm danh');

  // Đặt tên file thân thiện với thời gian thực
  const safeEventName = eventInfo.name.replace(/[^a-zA-Z0-9_\u00C0-\u1EF9]/g, '_').slice(0, 30);
  const dateStr = new Date().toISOString().slice(0, 10);
  const fileName = `DiemDanh_${safeEventName}_${dateStr}.xlsx`;

  // Tải file về máy
  XLSX.writeFile(workbook, fileName);
}

export function exportToCSV(attendees: Attendee[], eventInfo: EventInfo) {
  const headers = ['STT', 'Mã số (MSSV)', 'Họ và tên', 'Lớp', 'Khoa / Đơn vị', 'Thời gian điểm danh', 'Hình thức', 'Trạng thái'];
  
  const csvRows = attendees.map((item, index) => [
    index + 1,
    `"${item.mssv}"`,
    `"${item.name || ''}"`,
    `"${item.className || ''}"`,
    `"${item.department || ''}"`,
    `"${item.checkInTime}"`,
    `"${item.method === 'qr' ? 'Quét QR' : 'Nhập tay'}"`,
    `"${item.status}"`,
  ].join(','));

  const csvContent = '\uFEFF' + [headers.join(','), ...csvRows].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  
  const safeEventName = eventInfo.name.replace(/[^a-zA-Z0-9_\u00C0-\u1EF9]/g, '_').slice(0, 25);
  const dateStr = new Date().toISOString().slice(0, 10);
  link.setAttribute('href', url);
  link.setAttribute('download', `DiemDanh_${safeEventName}_${dateStr}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
